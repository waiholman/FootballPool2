﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballPool.Simulator.enums
{
    public enum PlayerRole
    {
        Keeper,
        Defender,
        Midfielder,
        Attacker
    }
}
