﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballPool.Simulator.enums
{
    public enum MatchResultEnum
    {
        Win,
        Draw,
        Skip
    }
}
